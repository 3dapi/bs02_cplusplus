/*
	HelloWorld3.cpp
*/

#include <iostream>

using std::cout;
using std::cin;
using std::endl;

int main(void)
{
	cout<<"Hello World!!"<<endl;
	cout<<"Hello "<<"World!!"<<endl;
	cout<<1<<'a'<<"String"<<endl;
	return 0;
}