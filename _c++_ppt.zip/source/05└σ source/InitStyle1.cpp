/*
   InitStyle1.cpp
*/
#include<iostream>
using std::cout;
using std::endl;

int main(void)
{
	int val1(20);
	int val2=40;

	cout<<"val1: "<<val1<<endl;
	cout<<"val2: "<<val2<<endl;

	return 0;
}