

#include <stdio.h>

void main()
{
	char	s[] = "�ȳ� Hello �ϼ��� world";
	char*	p = s;

	for(; *p != 0; ++p)
	{
		if( 'A' <=*p && *p <= 'Z')
			*p |= 0x20;	// 0010 0000;
	}


	printf("%s\n", s);
}