// _StdAfx.h
//
//////////////////////////////////////////////////////////////////////

#ifndef __STDAFX_H_
#define __STDAFX_H_

#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include <malloc.h>
#include <windows.h>


#include "TmpClass.h"


#endif __STDAFX_H_