/*
	HelloWorld4.cpp
*/

#include <iostream>

using namespace std;

int main(void)
{
	cout<<"Hello World!!"<<endl;
	cout<<"Hello "<<"World!!"<<endl;
	cout<<1<<'a'<<"String"<<endl;
	return 0;
}