/*
   DefaultSubProb1.cpp   
*/
#include <iostream>
using std::endl;
using std::cout;
using std::ostream;

class Person {
private:
	char* name;
public:
	Person(char* _name);
	Person(const Person& p);
	~Person();
	friend ostream& operator<<(ostream& os, const Person& p);
};

Person::Person(char* _name){
	name= new char[strlen(_name)+1];
	strcpy(name, _name);
}
Person::Person(const Person& p){
	name= new char[strlen(p.name)+1];
	strcpy(name, p.name);
}
Person::~Person(){
	delete[] name;
}

ostream& operator<<(ostream& os, const Person& p)
{
	os<<p.name;
	return os;
}

int main()
{
	Person p1("LEE JUNE");
	Person p2("HONG KEN");	

	cout<<p1<<endl;
	cout<<p2<<endl;

    p1=p2;  // ������ ����.

	cout<<p1<<endl;

	return 0;
}
