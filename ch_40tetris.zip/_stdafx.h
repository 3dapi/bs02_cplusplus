#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <time.h>

#include <iostream>

#include <windows.h>

#include <crtdbg.h>

#include "Input.h"
#include "Commonlib.h"
#include "Block.h"
#include "Console.h"
#include "Tetris.h"
#include "Stage.h"
#include "Player.h"
#include "Score.h"

#include "App.h"

extern CApp* g_pApp;