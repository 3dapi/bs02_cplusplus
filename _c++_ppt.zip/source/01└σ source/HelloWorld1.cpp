/*
	HelloWorld1.cpp
	Old Style Hello World!!	
*/

#include <iostream.h>

int main(void)
{
	cout<<"Hello World!!"<<endl;
	cout<<"Hello "<<"World!!"<<endl;
	cout<<1<<'a'<<"String"<<endl;
	return 0;
}