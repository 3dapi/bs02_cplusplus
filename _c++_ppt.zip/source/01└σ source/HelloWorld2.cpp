/*
	HelloWorld2.cpp
	Standard Style Hello World!!	
*/

#include <iostream>

int main(void)
{
	std::cout<<"Hello World!!"<<std::endl;
	std::cout<<"Hello "<<"World!!"<<std::endl;
	std::cout<<1<<'a'<<"String"<<std::endl;
	return 0;
}