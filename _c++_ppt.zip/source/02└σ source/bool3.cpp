/*
	bool3.cpp
	true & false
*/

#include <iostream>

using std::cout;
using std::endl;

int main(void)
{
	int BOOL=true;
	cout<<"BOOL : "<<BOOL<<endl;

	BOOL=false;
	cout<<"BOOL : "<<BOOL<<endl;

	return 0;
}